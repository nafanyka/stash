"""Turning a reviewed selection into exactly one write, and then forgetting everything.

This is the only module in FastDiscovery that changes anything in Stash, and it only
ever runs because somebody pressed Apply. Everything before it - the run, the results,
the review - leaves the scene untouched (requirements 7, 57).

The sequence, and the reasoning behind each step:

1. **rebuild the review against the live scene.** The selection arrives as value ids,
   which only mean something against the matrix they came from, and the scene may have
   changed since it was rendered. Rebuilding both resolves the ids and makes the
   change set true.
2. **drop the no-ops.** A field whose selected value is what the scene already has is
   not written. So the audit says what actually changed, and a stray field cannot be
   rewritten with its own value.
3. **create only what was explicitly ticked.** A performer, tag, studio or group that
   does not exist locally is created only if the user selected that candidate - never
   because it appeared in a result (requirements 12, 14, 15, 49).
4. **one `sceneUpdate`.** Every selected field in a single mutation, so the scene cannot
   end up half-applied. GraphQL gives no transaction across mutations, so the creates
   above happen first and are reported in the audit if the update then fails.
5. **purge on success only.** A failed apply keeps the whole payload and leaves the run
   reviewable, so Apply can simply be pressed again (requirement 20).
"""

from __future__ import annotations

from . import fields, logs, merge as merge_module
from .db import repo as R


# The mark an applied scene carries afterwards. A plain tag, so it is filterable in
# Stash like any other, and the only thing Apply writes that the reviewer did not tick.
# It is added by name, not by id: the tag may not exist yet on a fresh library, and it
# may have been deleted and remade since the last apply.
MARKER_TAG = "FastDiscovery"


class ApplyError(RuntimeError):
    """The selection could not be turned into a write. Nothing was changed."""


def preview(repo, client, run, scene, selection, schema_fields=None, rejected=None):
    """What Apply would do, without doing any of it."""
    review = merge_module.build(repo, run, scene, schema_fields, client, rejected)
    plan = _plan(review, selection)
    return {"changes": plan["changes"], "creates": plan["creates"],
            "unchanged": plan["unchanged"], "problems": plan["problems"],
            "will_tag": None if _has_marker(scene) else MARKER_TAG,
            "scene_updated_at": review["scene"]["updated_at"]}


def commit(repo, client, run, scene, selection, schema_fields=None,
           expected_updated_at=None, rejected=None):
    """Create what was ticked, write the scene once, then drop the payload.

    `rejected` has to be the same set the review was shown with: it decides which
    options exist at all, and applying against a different matrix than the one the
    reviewer read would write something they never saw.
    """
    review = merge_module.build(repo, run, scene, schema_fields, client, rejected)
    live_stamp = review["scene"]["updated_at"]
    if expected_updated_at and live_stamp and str(expected_updated_at) != str(live_stamp):
        # Someone edited the scene between the review being rendered and Apply being
        # pressed. Writing the older intent would silently undo their edit, so the
        # review is handed back refreshed instead.
        raise ApplyError("the scene changed since this review was loaded - reload it "
                         "and check the selection before applying")

    plan = _plan(review, selection)
    if plan["problems"]:
        raise ApplyError("; ".join(plan["problems"]))
    if not plan["changes"] and not plan["creates"]:
        # Nothing was selected that would change anything, so nothing is written - not
        # even the marker. An apply that writes nothing is not an apply: the review
        # stays open and the scene is left exactly as it was.
        return {"applied": False, "reason": "nothing was selected that would change "
                                            "the scene", "changes": [], "created": {}}

    created, linked = _create_entities(client, plan["creates"])
    values = _scene_update_input(repo, review, plan)
    # A scene that has been applied to carries the mark afterwards, so it can be told
    # apart in Stash from one FastDiscovery has never touched.
    marker = _mark_applied(client, scene, values, _has_marker(scene))
    values["id"] = str(run["scene_id"])

    logs.info("scene %s: applying %s"
              % (run["scene_id"], ", ".join(sorted(one["field"]
                                                   for one in plan["changes"]))))
    logs.debug("scene %s: update touches %s; entities created: %s"
               % (run["scene_id"], sorted(values), _created_summary(created)))

    try:
        client.scene_update(values)
    except Exception as exc:
        from .executor import describe_error
        message = describe_error(exc)
        repo.add_application(run["id"], run["scene_id"], "FAILED",
                             [one["field"] for one in plan["changes"]], created, message)
        repo.set_run_status(run["id"], R.FAILED_APPLY, message)
        raise ApplyError(message)

    repo.add_application(run["id"], run["scene_id"], "APPLIED",
                         [one["field"] for one in plan["changes"]],
                         {"created": created, "linked": linked, "marker": marker})
    repo.set_run_status(run["id"], R.APPLIED)
    repo.purge_run(run["id"])
    return {"applied": True, "changes": plan["changes"], "created": created,
            "linked": linked, "marker": marker, "fields": sorted(values)}


def preview_performer(repo, client, run, performer, selection, schema_fields=None,
                      rejected=None):
    """`preview()`'s sibling for a performer run."""
    review = merge_module.build_performer(repo, run, performer, schema_fields, client,
                                          rejected)
    plan = _plan(review, selection)
    return {"changes": plan["changes"], "creates": plan["creates"],
            "unchanged": plan["unchanged"], "problems": plan["problems"],
            "performer_updated_at": review["performer"]["updated_at"]}


def commit_performer(repo, client, run, performer, selection, schema_fields=None,
                     expected_updated_at=None, rejected=None, organize=False):
    """`commit()`'s sibling for a performer run.

    Identical shape and identical safety properties - rebuild against the live
    performer, refuse a stale write, create only what was ticked, one
    `performerUpdate`, purge only once that succeeds. The one addition is Organize
    (requirement: off by default, and only ever *sets* the flag, reusing the exact
    mechanism `PerformerOrganized` already uses - see `stash.Client.
    set_performer_organized`), applied after the field write succeeds so a failed
    Organize call cannot be mistaken for a failed apply of the reviewed fields.
    """
    review = merge_module.build_performer(repo, run, performer, schema_fields, client,
                                          rejected)
    live_stamp = review["performer"]["updated_at"]
    if expected_updated_at and live_stamp and str(expected_updated_at) != str(live_stamp):
        raise ApplyError("the performer changed since this review was loaded - reload "
                         "it and check the selection before applying")

    plan = _plan(review, selection)
    if plan["problems"]:
        raise ApplyError("; ".join(plan["problems"]))
    if not plan["changes"] and not plan["creates"] and not organize:
        return {"applied": False, "reason": "nothing was selected that would change "
                                            "the performer", "changes": [], "created": {}}

    created, linked = _create_entities(client, plan["creates"])
    values = _performer_update_input(repo, review, plan)
    values["id"] = str(run["scene_id"])   # the generic "subject id" column; see db/migrations.py

    logs.info("performer %s: applying %s"
              % (run["scene_id"], ", ".join(sorted(one["field"]
                                                   for one in plan["changes"]))
                                  or "(no field changes)"))

    if plan["changes"] or plan["creates"]:
        try:
            client.performer_update(values)
        except Exception as exc:
            from .executor import describe_error
            message = describe_error(exc)
            repo.add_application(run["id"], run["scene_id"], "FAILED",
                                 [one["field"] for one in plan["changes"]], created,
                                 message, entity_type="performer")
            repo.set_run_status(run["id"], R.FAILED_APPLY, message)
            raise ApplyError(message)

    organized = None
    if organize:
        try:
            client.set_performer_organized(run["scene_id"], True)
            organized = True
        except Exception as exc:
            from .executor import describe_error
            message = describe_error(exc)
            # The field write already succeeded; losing Organize on top of it must not
            # look like a failed apply, or the run would stay open for changes that
            # already happened, inviting a second, no-op performerUpdate.
            logs.warning("performer %s: field update applied, but Organize failed: %s"
                        % (run["scene_id"], message))

    repo.add_application(run["id"], run["scene_id"], "APPLIED",
                         [one["field"] for one in plan["changes"]],
                         {"created": created, "linked": linked, "organized": organized},
                         entity_type="performer")
    repo.set_run_status(run["id"], R.APPLIED)
    repo.purge_run(run["id"])
    return {"applied": True, "changes": plan["changes"], "created": created,
            "linked": linked, "organized": organized, "fields": sorted(values)}


def reject(repo, run):
    """No write at all, the payload dropped, one audit row kept (requirement 21).

    Entity-agnostic: a scene and a performer run reject exactly the same way, so this
    is the one function `ops.py` calls for either (`run["entity_type"]` says which
    audit bucket the row belongs to).
    """
    repo.add_application(run["id"], run["scene_id"], "REJECTED",
                         entity_type=run.get("entity_type") or "scene")
    repo.set_run_status(run["id"], R.REJECTED)
    repo.purge_run(run["id"])
    return {"rejected": True, "run_id": run["id"]}


# ------------------------------------------------------------------ planning

def _plan(review, selection):
    """Resolve the selection into changes, creations, and anything that made no sense."""
    selection = selection if isinstance(selection, dict) else {}
    changes, creates, unchanged, problems = [], [], [], []

    for row in review["rows"]:
        if not row["writable"]:
            continue
        if row["field"] not in selection:
            continue           # untouched fields are left exactly as they are
        chosen = selection[row["field"]]
        by_id = {value["id"]: value for value in row["values"]}
        # An entity that has since been recognised as one the library already has may
        # have absorbed another option; a tick made before that still resolves.
        for value in row["values"]:
            for absorbed in value.get("merged_ids") or []:
                by_id.setdefault(absorbed, value)

        if row["kind"] in (fields.SCALAR, fields.IMAGE, fields.ENTITY):
            if chosen is None:
                continue
            if not isinstance(chosen, str):
                # A single-choice row takes one option id. Anything else is a bug
                # somewhere above, and saying which field it was beats the TypeError
                # that indexing with it would raise.
                problems.append("%s: expected one option id, got %s"
                                % (row["field"], type(chosen).__name__))
                continue
            value = by_id.get(chosen)
            if value is None:
                problems.append("%s: no such option %r" % (row["field"], chosen))
                continue
            if value.get("is_current") or value.get("on_scene"):
                unchanged.append(row["field"])
                continue
            changes.append({"field": row["field"], "kind": row["kind"],
                            "value_id": value["id"],
                            "display": _display_of(row, value)})
            if row["kind"] == fields.ENTITY and not value.get("stored_id"):
                creates.append({"field": row["field"], "kind": row["entity"],
                                "entity": value})
            continue

        if not isinstance(chosen, list):
            # An absent or null list is "the user did not touch this row", not "empty
            # it". Clearing a list is done by sending an empty list, which is what the
            # UI sends when every box is unticked.
            problems.append("%s: expected a list of choices" % row["field"])
            continue
        wanted = list(chosen)
        malformed = [one for one in wanted if not isinstance(one, str)]
        if malformed:
            problems.append("%s: expected option ids, got %s"
                            % (row["field"],
                               ", ".join(sorted({type(one).__name__
                                                 for one in malformed}))))
            continue
        missing = [one for one in wanted if one not in by_id]
        if missing:
            problems.append("%s: no such option(s) %s"
                            % (row["field"], ", ".join(str(one) for one in missing)))
            continue
        picked, seen_picked = [], set()
        for one in wanted:
            value = by_id[one]
            if value["id"] in seen_picked:
                continue       # two ids that turned out to be the same thing
            seen_picked.add(value["id"])
            picked.append(value)
        present = [value["id"] for value in row["values"]
                   if value.get("is_current") or value.get("on_scene")]
        if sorted({by_id[one]["id"] for one in wanted}) == sorted(present):
            unchanged.append(row["field"])
            continue
        added = [value for value in picked
                 if not (value.get("is_current") or value.get("on_scene"))]
        exclusive = row.get("exclusive_by")
        if exclusive:
            seen_keys = {}
            for value in picked:
                key = value.get(exclusive)
                if key in seen_keys:
                    problems.append(
                        "%s: a scene can only hold one value per %s, but two were "
                        "chosen for %r - pick one" % (row["field"], exclusive, key))
                seen_keys[key] = value["id"]
            if problems:
                continue

        kept = {value["id"] for value in picked}
        removed = [by_id[one] for one in present if one not in kept]
        changes.append({
            "field": row["field"], "kind": row["kind"],
            "value_ids": [value["id"] for value in picked],
            "added": [_display_of(row, value) for value in added],
            "removed": [_display_of(row, value) for value in removed],
        })
        for value in picked:
            if row["kind"] == fields.ENTITY_LIST and not value.get("stored_id"):
                creates.append({"field": row["field"], "kind": row["entity"],
                                "entity": value})

    return {"changes": changes, "creates": creates, "unchanged": unchanged,
            "problems": problems}


def _display_of(row, value):
    if row["kind"] in (fields.ENTITY, fields.ENTITY_LIST):
        return value["name"]
    if row["kind"] == fields.IMAGE:
        return value.get("url") or ("image " + str(value.get("sha256"))[:12])
    return value.get("display")


# ------------------------------------------------------------------ creation

def _create_entities(client, creates):
    """Resolve the ticked candidates to ids, creating only what genuinely is missing.

    Every candidate is looked up by name one last time, immediately before it would be
    created. That closes a window nothing else can: the review says "does not exist yet"
    as of the moment it was built, and between then and now the same performer can have
    been created by the review of another scene, by a second browser tab, or by hand.
    Creating blindly turns that into a unique-constraint error from Stash's database,
    with a whole apply lost behind it.

    The lookup is not capped, unlike the one that labels the review: there are only ever
    as many of these as the user actually ticked.

    A candidate selected twice - the same new performer under two fields - is handled
    once. Nothing that already exists is ever created, and nothing else is created at all.
    """
    created = {}
    linked = {}
    seen = {}
    for entry in creates:
        entity = entry["entity"]
        kind = entry["kind"]
        marker = (kind, entity["canon"], entity.get("disambiguation") or "")
        if marker in seen:
            entity["stored_id"] = seen[marker]
            continue

        record, was_created = _resolve_or_create(client, kind, entity)
        entity["stored_id"] = str(record["id"])
        seen[marker] = entity["stored_id"]
        bucket = created if was_created else linked
        bucket.setdefault(kind, []).append({"id": entity["stored_id"],
                                            "name": entity["name"]})
        logs.info("%s %s %s (id %s)"
                  % ("created" if was_created else "linked existing", kind,
                     entity["name"], entity["stored_id"]))
    return ({kind: rows for kind, rows in created.items() if rows},
            {kind: rows for kind, rows in linked.items() if rows})


def _resolve_or_create(client, kind, entity):
    """(record, was_created) for one ticked candidate."""
    existing = merge_module.find_local_entity(client, kind, entity["name"],
                                              entity.get("canon"))
    if existing:
        return existing, False
    try:
        record = _create_one(client, kind, entity)
    except Exception as exc:
        # Somebody created it between the lookup above and this call, or it collides
        # with an alias the name lookup cannot see. Ask once more: if it is there now,
        # link it and carry on, because that is what the user asked for either way.
        second = merge_module.find_local_entity(client, kind, entity["name"],
                                                entity.get("canon"))
        if second:
            return second, False
        from .executor import describe_error
        raise ApplyError("could not create %s %r: %s"
                         % (kind, entity["name"], describe_error(exc)))
    if record is None:
        raise ApplyError("could not create %s %r" % (kind, entity["name"]))
    return record, True


def _has_marker(scene):
    """Is the scene already tagged, by name?

    Read off the live scene rather than the review, for two reasons: the tags row is
    absent altogether from a review where neither the scene nor any result had tags,
    and this has to be true of the scene as it is now, not of the matrix.

    By name, because the common case then costs no lookup at all: the tags a scene
    carries either include one called FastDiscovery or they do not.
    """
    target = fields.canon_name(MARKER_TAG)
    return any(fields.canon_name(tag.get("name")) == target
               for tag in ((scene or {}).get("tags") or []))


def _mark_applied(client, scene, values, marked):
    """Put the FastDiscovery tag into the write, creating it the first time.

    Returns what was added, or None when the scene keeps the tag it already had and
    this write does not touch tags at all - there is nothing to say and nothing to do.

    The tag joins the same `tag_ids` the reviewed selection produced, never a second
    mutation: a scene must not be able to come out of Apply marked as dealt with while
    half of what was ticked failed to write.

    When the selection did not touch tags, `tag_ids` is built from the tags the scene
    has right now, so marking it adds one tag and removes none.
    """
    if marked and "tag_ids" not in values:
        return None

    wanted = ([str(one) for one in values["tag_ids"]] if "tag_ids" in values
              else [str(tag["id"]) for tag in ((scene or {}).get("tags") or [])
                    if tag.get("id")])

    record, was_created = _resolve_or_create(
        client, "tag", {"name": MARKER_TAG, "canon": fields.canon_name(MARKER_TAG)})
    marker_id = str(record["id"])
    if marker_id in wanted:
        return None
    wanted.append(marker_id)
    values["tag_ids"] = wanted
    logs.info("tagged scene %s as %s"
              % ((scene or {}).get("id"), record.get("name") or MARKER_TAG))
    return {"id": marker_id, "name": record.get("name") or MARKER_TAG,
            "created": was_created}


def _create_one(client, kind, entity):
    values = {"name": entity["name"]}
    urls = [url for url in (entity.get("urls") or []) if url][:10]
    stash_ids = [{"endpoint": one["endpoint"], "stash_id": one["stash_id"]}
                 for one in (entity.get("remote_ids") or [])]

    if kind == "performer":
        if entity.get("disambiguation"):
            values["disambiguation"] = entity["disambiguation"]
        if urls:
            values["urls"] = urls
        if stash_ids:
            values["stash_ids"] = stash_ids
        if entity.get("image"):
            values["image"] = entity["image"]
        return client.create_performer(values)
    if kind == "studio":
        if urls:
            values["urls"] = urls
        if stash_ids:
            values["stash_ids"] = stash_ids
        if entity.get("image"):
            values["image"] = entity["image"]
        return client.create_studio(values)
    if kind == "group":
        return client.create_group(values)
    # Tags carry nothing but a name in a scraped result, and a tag with an invented
    # description would be worse than one without.
    return client.create_tag(values)


# ------------------------------------------------------------------ the write

def _scene_update_input(repo, review, plan):
    """The `SceneUpdateInput` for the whole change set.

    Set-like fields are sent as the exact set the review showed as ticked, which is the
    reviewed intent - the user saw what is on the scene now and what would be added, and
    unticking something is how they remove it. Fields not in the change set are absent
    from the input, so `sceneUpdate` leaves them alone.
    """
    rows = {row["field"]: row for row in review["rows"]}
    values = {}

    for change in plan["changes"]:
        row = rows[change["field"]]
        field = fields.BY_NAME.get(change["field"])
        key = field.update_key if field else row["field"]
        by_id = {value["id"]: value for value in row["values"]}

        if row["kind"] == fields.SCALAR:
            values[key] = _scalar_for_update(change["field"],
                                             by_id[change["value_id"]]["raw"])
        elif row["kind"] == fields.IMAGE:
            image = _image_for_update(repo, by_id[change["value_id"]])
            if image is None:
                raise ApplyError("the selected image is no longer available")
            values[key] = image
        elif row["kind"] == fields.ENTITY:
            values[key] = str(by_id[change["value_id"]]["stored_id"])
        elif row["kind"] == fields.ENTITY_LIST:
            picked = [by_id[one] for one in change["value_ids"]]
            if row["field"] == "groups":
                values[key] = [{"group_id": str(entity["stored_id"]),
                                "scene_index": entity.get("scene_index")}
                               for entity in picked if entity.get("stored_id")]
            else:
                values[key] = [str(entity["stored_id"]) for entity in picked
                               if entity.get("stored_id")]
        elif row["kind"] == fields.URL_LIST:
            values[key] = [by_id[one]["raw"] for one in change["value_ids"]]
        elif row["kind"] == fields.STASH_ID:
            values[key] = [{"endpoint": by_id[one]["endpoint"],
                            "stash_id": by_id[one]["stash_id"]}
                           for one in change["value_ids"]]
    return values


_GENDER_ENUM = {"male", "female", "transgender_male", "transgender_female",
                "intersex", "non_binary"}
_CIRCUMCISED_ENUM = {"cut", "uncut"}


def _performer_update_input(repo, review, plan):
    """`_scene_update_input`'s sibling for a performer.

    Two real type differences from a scene's fields, both resolved here and nowhere
    else: `height`/`weight` arrive as free text and Stash stores an integer
    (`fields.parse_int_prefix`); `gender`/`circumcised` arrive as free text and Stash
    stores an enum, accepted case-insensitively and left out of the write entirely
    when the scraped word is not one Stash recognises, rather than sending a value the
    mutation would reject and losing every other field in the same update to it.
    """
    rows = {row["field"]: row for row in review["rows"]}
    values = {}

    for change in plan["changes"]:
        row = rows[change["field"]]
        field = fields.PERFORMER_BY_NAME.get(change["field"])
        key = field.update_key if field else row["field"]
        by_id = {value["id"]: value for value in row["values"]}

        if row["kind"] == fields.SCALAR:
            coerced = _performer_scalar_for_update(
                change["field"], by_id[change["value_id"]]["raw"])
            # A value that did not coerce to anything Stash's typed column accepts
            # (an unrecognised gender/circumcised word, a height/weight with no
            # digits) is left out of the write entirely rather than sent as null,
            # which would clear the field instead of leaving it as it was.
            if coerced is not None:
                values[key] = coerced
            continue
        elif row["kind"] == fields.IMAGE:
            image = _image_for_update(repo, by_id[change["value_id"]])
            if image is None:
                raise ApplyError("the selected image is no longer available")
            values[key] = image
        elif row["kind"] == fields.ENTITY_LIST:
            picked = [by_id[one] for one in change["value_ids"]]
            values[key] = [str(entity["stored_id"]) for entity in picked
                           if entity.get("stored_id")]
        elif row["kind"] == fields.URL_LIST:
            values[key] = [by_id[one]["raw"] for one in change["value_ids"]]
        elif row["kind"] == fields.STASH_ID:
            values[key] = [{"endpoint": by_id[one]["endpoint"],
                            "stash_id": by_id[one]["stash_id"]}
                           for one in change["value_ids"]]
    return values


def _performer_scalar_for_update(name, raw):
    if name == "height":
        return fields.parse_int_prefix(raw)
    if name == "weight":
        return fields.parse_int_prefix(raw)
    if name == "gender":
        word = fields.clean(raw)
        return word.strip().upper().replace(" ", "_") if word and \
            word.strip().lower().replace(" ", "_") in _GENDER_ENUM else None
    if name == "circumcised":
        word = fields.clean(raw)
        return word.strip().upper() if word and word.strip().lower() in \
            _CIRCUMCISED_ENUM else None
    if name == "aliases":
        parts = [one.strip() for one in str(raw or "").split(",") if one.strip()]
        return parts
    return fields.clean(raw)


def _scalar_for_update(name, raw):
    if name == "date":
        return fields.parse_date(raw) or fields.clean(raw)
    if name == "rating100":
        try:
            return int(raw)
        except (TypeError, ValueError):
            return None
    return fields.clean(raw)


def _image_for_update(repo, value):
    """What `cover_image` gets.

    Stash accepts either a URL or a base64 data URI and fetches the URL itself
    (`utils.ProcessImageInput`), so an image that arrived as a URL is passed on as one -
    FastDiscovery never downloads a cover. An image that arrived as a data URI is
    rebuilt from the blob it was stored as, byte for byte.
    """
    if value.get("kind") in ("url", "scene"):
        return value.get("url")
    blob = repo.image(value.get("sha256")) if value.get("sha256") else None
    if not blob:
        return None
    import base64
    return "data:%s;base64,%s" % (blob["mime"],
                                  base64.b64encode(blob["data"]).decode("ascii"))


def _created_summary(created):
    return {kind: len(rows) for kind, rows in (created or {}).items()}
